import { useState, useRef } from "react";

const ROOMS = [
  "Entrée", "Salon", "Séjour", "Cuisine", "Chambre 1",
  "Chambre 2", "Chambre 3", "Salle de bain", "WC", "Couloir",
  "Cave", "Garage", "Buanderie", "Balcon / Terrasse"
];

const ETAT_OPTIONS = ["Neuf", "Très bon", "Bon", "Moyen", "Mauvais"];

const ETAT_COLORS = {
  "Neuf": "#16a34a",
  "Très bon": "#65a30d",
  "Bon": "#ca8a04",
  "Moyen": "#ea580c",
  "Mauvais": "#dc2626"
};

function SignaturePad({ onSave, label }) {
  const canvasRef = useRef();
  const [drawing, setDrawing] = useState(false);
  const [signed, setSigned] = useState(false);
  const lastPos = useRef(null);

  const getPos = (e, canvas) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;
    return { x: (clientX - rect.left) * scaleX, y: (clientY - rect.top) * scaleY };
  };

  const startDraw = (e) => {
    e.preventDefault();
    setDrawing(true);
    const canvas = canvasRef.current;
    const pos = getPos(e, canvas);
    lastPos.current = pos;
    const ctx = canvas.getContext("2d");
    ctx.beginPath();
    ctx.moveTo(pos.x, pos.y);
  };

  const draw = (e) => {
    e.preventDefault();
    if (!drawing) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const pos = getPos(e, canvas);
    ctx.strokeStyle = "#1e293b";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.lineTo(pos.x, pos.y);
    ctx.stroke();
    lastPos.current = pos;
    setSigned(true);
  };

  const endDraw = (e) => {
    e.preventDefault();
    setDrawing(false);
    if (signed && canvasRef.current) {
      onSave(canvasRef.current.toDataURL());
    }
  };

  const clear = () => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setSigned(false);
    onSave(null);
  };

  return (
    <div>
      <div style={{ fontSize: 13, fontWeight: 600, color: "#334155", marginBottom: 6 }}>{label}</div>
      <div style={{ border: "2px solid #cbd5e1", borderRadius: 10, background: "#f8fafc", overflow: "hidden" }}>
        <canvas
          ref={canvasRef}
          width={480}
          height={120}
          style={{ display: "block", width: "100%", touchAction: "none", cursor: "crosshair" }}
          onMouseDown={startDraw}
          onMouseMove={draw}
          onMouseUp={endDraw}
          onTouchStart={startDraw}
          onTouchMove={draw}
          onTouchEnd={endDraw}
        />
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 4 }}>
        <span style={{ fontSize: 11, color: "#94a3b8" }}>Signez dans le cadre ci-dessus</span>
        {signed && (
          <button onClick={clear} style={{ background: "none", border: "none", color: "#ef4444", fontSize: 12, cursor: "pointer" }}>
            ✕ Effacer
          </button>
        )}
      </div>
    </div>
  );
}

const STEPS = ["Infos", "Pièces", "Compteurs", "Signatures", "Récap"];

function StepIndicator({ current }) {
  return (
    <div style={{ display: "flex", justifyContent: "center", gap: 0, marginBottom: 24, padding: "0 8px" }}>
      {STEPS.map((s, i) => (
        <div key={s} style={{ display: "flex", alignItems: "center", flex: 1 }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", flex: 1 }}>
            <div style={{
              width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center",
              background: i < current ? "#3b82f6" : i === current ? "#1d4ed8" : "#e2e8f0",
              color: i <= current ? "#fff" : "#94a3b8",
              fontWeight: 700, fontSize: 13,
              boxShadow: i === current ? "0 0 0 3px #bfdbfe" : "none",
              transition: "all 0.2s"
            }}>{i < current ? "✓" : i + 1}</div>
            <div style={{ fontSize: 10, marginTop: 2, color: i === current ? "#1d4ed8" : "#94a3b8", fontWeight: i === current ? 700 : 400 }}>{s}</div>
          </div>
          {i < STEPS.length - 1 && (
            <div style={{ height: 2, flex: 0.5, background: i < current ? "#3b82f6" : "#e2e8f0", marginBottom: 16, transition: "background 0.3s" }} />
          )}
        </div>
      ))}
    </div>
  );
}

const card = { background: "#fff", borderRadius: 14, padding: 16, marginBottom: 14, boxShadow: "0 1px 4px rgba(0,0,0,0.07)" };
const inputStyle = { width: "100%", border: "1.5px solid #e2e8f0", borderRadius: 8, padding: "10px 12px", fontSize: 14, outline: "none", background: "#f8fafc", boxSizing: "border-box" };
const labelStyle = { fontSize: 12, fontWeight: 600, color: "#475569", marginBottom: 4, display: "block" };
const btnPrimary = { background: "#1d4ed8", color: "#fff", border: "none", borderRadius: 10, padding: "13px 28px", fontSize: 15, fontWeight: 700, cursor: "pointer", width: "100%", marginTop: 8 };
const btnSecondary = { background: "#f1f5f9", color: "#334155", border: "none", borderRadius: 10, padding: "13px 28px", fontSize: 15, fontWeight: 700, cursor: "pointer", width: "100%", marginTop: 8 };

export default function EtatDesLieux() {
  const [step, setStep] = useState(0);
  const [type, setType] = useState("entrant");
  const [owner, setOwner] = useState({ nom: "", adresse: "", telephone: "" });
  const [tenant, setTenant] = useState({ nom: "", telephone: "", photo: null });
  const [logement, setLogement] = useState({ adresse: "", type: "", surface: "" });
  const [rooms, setRooms] = useState({});
  const [selectedRooms, setSelectedRooms] = useState(["Entrée", "Salon", "Cuisine", "Salle de bain", "WC"]);
  const [compteurs, setCompteurs] = useState({ eau: "", gaz: "", electricite: "", photos: {} });
  const [cles, setCles] = useState({ nombre: "", remises: "" });
  const [sigOwner, setSigOwner] = useState(null);
  const [sigTenant, setSigTenant] = useState(null);
  const [expandedRoom, setExpandedRoom] = useState(null);
  const [done, setDone] = useState(false);
  const tenantPhotoRef = useRef();
  const photoInputRefs = useRef({});
  const meterRefs = { eau: useRef(), electricite: useRef(), gaz: useRef() };

  const date = new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" });

  const updateRoom = (room, field, value) => {
    setRooms(r => ({ ...r, [room]: { ...r[room], [field]: value } }));
  };

  const addRoomPhoto = (room, photo) => {
    if (!photo) return;
    setRooms(r => ({ ...r, [room]: { ...r[room], photos: [...(r[room]?.photos || []), photo] } }));
  };

  const removeRoomPhoto = (room, idx) => {
    setRooms(r => {
      const photos = [...(r[room]?.photos || [])];
      photos.splice(idx, 1);
      return { ...r, [room]: { ...r[room], photos } };
    });
  };

  // STEP 0 — Infos
  const StepInfos = () => (
    <div>
      <div style={card}>
        <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
          {["entrant", "sortant"].map(t => (
            <button key={t} onClick={() => setType(t)} style={{
              flex: 1, padding: "10px 0", borderRadius: 8, border: "2px solid",
              borderColor: type === t ? "#1d4ed8" : "#e2e8f0",
              background: type === t ? "#eff6ff" : "#fff",
              color: type === t ? "#1d4ed8" : "#64748b",
              fontWeight: type === t ? 700 : 400, fontSize: 14, cursor: "pointer"
            }}>
              {t === "entrant" ? "📥 Entrée" : "📤 Sortie"}
            </button>
          ))}
        </div>
        <div style={{ fontSize: 12, color: "#64748b", textAlign: "center" }}>
          État des lieux d'<strong>{type === "entrant" ? "entrée" : "sortie"}</strong> — {date}
        </div>
      </div>

      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 12 }}>🏠 Logement</div>
        <label style={labelStyle}>Adresse complète</label>
        <input style={{ ...inputStyle, marginBottom: 10 }} value={logement.adresse} onChange={e => setLogement(l => ({ ...l, adresse: e.target.value }))} placeholder="12 rue des Lilas, 75011 Paris" />
        <div style={{ display: "flex", gap: 10 }}>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Type</label>
            <select style={inputStyle} value={logement.type} onChange={e => setLogement(l => ({ ...l, type: e.target.value }))}>
              <option value="">Choisir...</option>
              <option>Appartement</option>
              <option>Maison</option>
              <option>Studio</option>
              <option>Local commercial</option>
            </select>
          </div>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Surface (m²)</label>
            <input style={inputStyle} type="number" value={logement.surface} onChange={e => setLogement(l => ({ ...l, surface: e.target.value }))} placeholder="45" />
          </div>
        </div>
      </div>

      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 12 }}>👤 Propriétaire / Bailleur</div>
        <label style={labelStyle}>Nom complet</label>
        <input style={{ ...inputStyle, marginBottom: 10 }} value={owner.nom} onChange={e => setOwner(o => ({ ...o, nom: e.target.value }))} placeholder="Jean Dupont" />
        <label style={labelStyle}>Adresse</label>
        <input style={{ ...inputStyle, marginBottom: 10 }} value={owner.adresse} onChange={e => setOwner(o => ({ ...o, adresse: e.target.value }))} placeholder="5 avenue Victor Hugo, 69002 Lyon" />
        <label style={labelStyle}>Téléphone</label>
        <input style={inputStyle} type="tel" value={owner.telephone} onChange={e => setOwner(o => ({ ...o, telephone: e.target.value }))} placeholder="06 12 34 56 78" />
      </div>

      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 12 }}>👤 Locataire</div>
        <label style={labelStyle}>Nom complet</label>
        <input style={{ ...inputStyle, marginBottom: 10 }} value={tenant.nom} onChange={e => setTenant(t => ({ ...t, nom: e.target.value }))} placeholder="Marie Martin" />
        <label style={labelStyle}>Téléphone</label>
        <input style={{ ...inputStyle, marginBottom: 12 }} type="tel" value={tenant.telephone} onChange={e => setTenant(t => ({ ...t, telephone: e.target.value }))} placeholder="06 98 76 54 32" />
        <label style={labelStyle}>Photo d'identité du locataire</label>
        {tenant.photo ? (
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <img src={tenant.photo} alt="ID" style={{ width: 80, height: 100, objectFit: "cover", borderRadius: 8, border: "2px solid #3b82f6" }} />
            <button onClick={() => setTenant(t => ({ ...t, photo: null }))} style={{ background: "#fee2e2", color: "#dc2626", border: "none", borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontSize: 13 }}>
              ✕ Supprimer
            </button>
          </div>
        ) : (
          <button onClick={() => tenantPhotoRef.current.click()}
            style={{ background: "#f1f5f9", border: "2px dashed #94a3b8", borderRadius: 10, padding: "20px", cursor: "pointer", color: "#475569", fontSize: 13, width: "100%", display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 28 }}>🪪</span>
            <span>Ajouter une photo d'identité</span>
            <span style={{ fontSize: 11, color: "#94a3b8" }}>Format carte d'identité ou passeport</span>
          </button>
        )}
        <input ref={tenantPhotoRef} type="file" accept="image/*" capture="environment" style={{ display: "none" }}
          onChange={e => {
            const file = e.target.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = ev => setTenant(t => ({ ...t, photo: ev.target.result }));
            reader.readAsDataURL(file); e.target.value = "";
          }} />
      </div>
      <button style={btnPrimary} onClick={() => setStep(1)}>Suivant →</button>
    </div>
  );

  // STEP 1 — Pièces
  const StepPieces = () => (
    <div>
      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 10 }}>Sélectionnez les pièces</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {ROOMS.map(r => (
            <button key={r} onClick={() => setSelectedRooms(s => s.includes(r) ? s.filter(x => x !== r) : [...s, r])}
              style={{ padding: "6px 12px", borderRadius: 20, border: "1.5px solid", fontSize: 12, cursor: "pointer",
                borderColor: selectedRooms.includes(r) ? "#3b82f6" : "#e2e8f0",
                background: selectedRooms.includes(r) ? "#eff6ff" : "#fff",
                color: selectedRooms.includes(r) ? "#1d4ed8" : "#64748b",
                fontWeight: selectedRooms.includes(r) ? 600 : 400
              }}>{r}</button>
          ))}
        </div>
      </div>

      {selectedRooms.map(room => {
        const r = rooms[room] || {};
        const isExpanded = expandedRoom === room;
        return (
          <div key={room} style={{ ...card, padding: 0, overflow: "hidden" }}>
            <button onClick={() => setExpandedRoom(isExpanded ? null : room)}
              style={{ width: "100%", background: "none", border: "none", padding: "14px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", cursor: "pointer" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontWeight: 700, fontSize: 14, color: "#1e293b" }}>{room}</span>
                {r.etat && <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 10, background: ETAT_COLORS[r.etat] + "22", color: ETAT_COLORS[r.etat], fontWeight: 600 }}>{r.etat}</span>}
                {r.photos?.length > 0 && <span style={{ fontSize: 11, color: "#64748b" }}>📷 {r.photos.length}</span>}
              </div>
              <span style={{ color: "#94a3b8", fontSize: 16 }}>{isExpanded ? "▲" : "▼"}</span>
            </button>
            {isExpanded && (
              <div style={{ padding: "0 16px 16px", borderTop: "1px solid #f1f5f9" }}>
                <label style={{ ...labelStyle, marginTop: 12 }}>État général</label>
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
                  {ETAT_OPTIONS.map(o => (
                    <button key={o} onClick={() => updateRoom(room, "etat", o)}
                      style={{ padding: "6px 12px", borderRadius: 20, border: "2px solid", fontSize: 12, cursor: "pointer",
                        borderColor: r.etat === o ? ETAT_COLORS[o] : "#e2e8f0",
                        background: r.etat === o ? ETAT_COLORS[o] + "22" : "#fff",
                        color: r.etat === o ? ETAT_COLORS[o] : "#64748b",
                        fontWeight: r.etat === o ? 700 : 400
                      }}>{o}</button>
                  ))}
                </div>
                <label style={labelStyle}>Observations</label>
                <textarea style={{ ...inputStyle, minHeight: 70, resize: "vertical", marginBottom: 12 }}
                  value={r.observations || ""}
                  onChange={e => updateRoom(room, "observations", e.target.value)}
                  placeholder="Décrivez l'état, les défauts constatés..." />
                <label style={labelStyle}>Photos de la pièce</label>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 8 }}>
                  {(r.photos || []).map((p, i) => (
                    <div key={i} style={{ position: "relative" }}>
                      <img src={p} alt="" style={{ width: 90, height: 68, objectFit: "cover", borderRadius: 8, border: "1.5px solid #e2e8f0" }} />
                      <button onClick={() => removeRoomPhoto(room, i)}
                        style={{ position: "absolute", top: -6, right: -6, background: "#ef4444", color: "#fff", border: "none", borderRadius: "50%", width: 18, height: 18, cursor: "pointer", fontSize: 10 }}>✕</button>
                    </div>
                  ))}
                  <button onClick={() => photoInputRefs.current[room]?.click()}
                    style={{ width: 90, height: 68, background: "#f8fafc", border: "2px dashed #94a3b8", borderRadius: 8, cursor: "pointer", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", color: "#94a3b8", fontSize: 11 }}>
                    <span style={{ fontSize: 20 }}>+</span><span>Photo</span>
                  </button>
                  <input ref={el => photoInputRefs.current[room] = el} type="file" accept="image/*" capture="environment" style={{ display: "none" }}
                    onChange={e => {
                      const file = e.target.files[0]; if (!file) return;
                      const reader = new FileReader();
                      reader.onload = ev => addRoomPhoto(room, ev.target.result);
                      reader.readAsDataURL(file); e.target.value = "";
                    }} />
                </div>
              </div>
            )}
          </div>
        );
      })}

      <div style={{ display: "flex", gap: 10 }}>
        <button style={{ ...btnSecondary, flex: 1 }} onClick={() => setStep(0)}>← Retour</button>
        <button style={{ ...btnPrimary, flex: 1 }} onClick={() => setStep(2)}>Suivant →</button>
      </div>
    </div>
  );

  // STEP 2 — Compteurs
  const StepCompteurs = () => (
    <div>
      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 15, color: "#1e293b", marginBottom: 14 }}>⚡ Relevés des compteurs</div>
        {[
          { key: "electricite", label: "Électricité (kWh)", icon: "⚡", ref: meterRefs.electricite },
          { key: "eau", label: "Eau (m³)", icon: "💧", ref: meterRefs.eau },
          { key: "gaz", label: "Gaz (m³)", icon: "🔥", ref: meterRefs.gaz }
        ].map(({ key, label, icon, ref }) => (
          <div key={key} style={{ marginBottom: 14 }}>
            <label style={labelStyle}>{icon} {label}</label>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <input style={{ ...inputStyle, flex: 1 }} type="number" value={compteurs[key]}
                onChange={e => setCompteurs(c => ({ ...c, [key]: e.target.value }))} placeholder="Ex: 12345" />
              {compteurs.photos?.[key] ? (
                <div style={{ position: "relative" }}>
                  <img src={compteurs.photos[key]} alt={key} style={{ width: 56, height: 42, objectFit: "cover", borderRadius: 6, border: "2px solid #3b82f6" }} />
                  <button onClick={() => setCompteurs(c => ({ ...c, photos: { ...c.photos, [key]: null } }))}
                    style={{ position: "absolute", top: -6, right: -6, background: "#ef4444", color: "#fff", border: "none", borderRadius: "50%", width: 16, height: 16, cursor: "pointer", fontSize: 9 }}>✕</button>
                </div>
              ) : (
                <button onClick={() => ref.current?.click()}
                  style={{ background: "#f1f5f9", border: "1.5px solid #e2e8f0", borderRadius: 8, padding: "8px", cursor: "pointer", fontSize: 18 }}>📷</button>
              )}
              <input ref={ref} type="file" accept="image/*" capture="environment" style={{ display: "none" }}
                onChange={e => {
                  const file = e.target.files[0]; if (!file) return;
                  const reader = new FileReader();
                  reader.onload = ev => setCompteurs(c => ({ ...c, photos: { ...c.photos, [key]: ev.target.result } }));
                  reader.readAsDataURL(file); e.target.value = "";
                }} />
            </div>
          </div>
        ))}
      </div>

      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 15, color: "#1e293b", marginBottom: 14 }}>🔑 Clés remises</div>
        <div style={{ display: "flex", gap: 10, marginBottom: 10 }}>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Nombre de clés</label>
            <input style={inputStyle} type="number" value={cles.nombre}
              onChange={e => setCles(c => ({ ...c, nombre: e.target.value }))} placeholder="Ex: 2" />
          </div>
          <div style={{ flex: 1 }}>
            <label style={labelStyle}>Dont remises</label>
            <input style={inputStyle} type="number" value={cles.remises}
              onChange={e => setCles(c => ({ ...c, remises: e.target.value }))} placeholder="Ex: 2" />
          </div>
        </div>
        <label style={labelStyle}>Détail (badges, télécommandes...)</label>
        <textarea style={{ ...inputStyle, minHeight: 60, resize: "vertical" }}
          value={cles.detail || ""}
          onChange={e => setCles(c => ({ ...c, detail: e.target.value }))}
          placeholder="Ex: 2 clés boîte aux lettres, 1 télécommande garage..." />
      </div>

      <div style={{ display: "flex", gap: 10 }}>
        <button style={{ ...btnSecondary, flex: 1 }} onClick={() => setStep(1)}>← Retour</button>
        <button style={{ ...btnPrimary, flex: 1 }} onClick={() => setStep(3)}>Suivant →</button>
      </div>
    </div>
  );

  // STEP 3 — Signatures
  const StepSignatures = () => (
    <div>
      <div style={{ ...card, background: "#fffbeb", border: "1px solid #fde68a" }}>
        <div style={{ fontSize: 13, color: "#92400e", display: "flex", gap: 8, alignItems: "flex-start" }}>
          <span style={{ fontSize: 16 }}>⚠️</span>
          <span>En signant ce document, les deux parties attestent avoir constaté ensemble l'état du logement et acceptent les informations renseignées.</span>
        </div>
      </div>

      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 14 }}>✍️ Signature du propriétaire</div>
        <div style={{ fontSize: 13, color: "#64748b", marginBottom: 10 }}>
          {owner.nom || "Propriétaire"} — {date}
        </div>
        <SignaturePad label="Signature du propriétaire / bailleur" onSave={setSigOwner} />
        {sigOwner && (
          <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 6, color: "#16a34a", fontSize: 13, fontWeight: 600 }}>
            <span>✓</span><span>Signature enregistrée</span>
          </div>
        )}
      </div>

      <div style={card}>
        <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 14 }}>✍️ Signature du locataire</div>
        <div style={{ fontSize: 13, color: "#64748b", marginBottom: 10 }}>
          {tenant.nom || "Locataire"} — {date}
        </div>
        <SignaturePad label="Signature du locataire" onSave={setSigTenant} />
        {sigTenant && (
          <div style={{ marginTop: 8, display: "flex", alignItems: "center", gap: 6, color: "#16a34a", fontSize: 13, fontWeight: 600 }}>
            <span>✓</span><span>Signature enregistrée</span>
          </div>
        )}
      </div>

      <div style={{ display: "flex", gap: 10 }}>
        <button style={{ ...btnSecondary, flex: 1 }} onClick={() => setStep(2)}>← Retour</button>
        <button
          style={{ ...btnPrimary, flex: 1, opacity: (!sigOwner || !sigTenant) ? 0.5 : 1 }}
          onClick={() => { if (sigOwner && sigTenant) setStep(4); }}
        >
          Finaliser →
        </button>
      </div>
      {(!sigOwner || !sigTenant) && (
        <div style={{ textAlign: "center", fontSize: 12, color: "#94a3b8", marginTop: 8 }}>
          Les deux signatures sont requises pour continuer
        </div>
      )}
    </div>
  );

  // STEP 4 — Récap
  const StepRecap = () => {
    const roomsFilled = selectedRooms.filter(r => rooms[r]?.etat);
    const roomsTotal = selectedRooms.length;
    const hasIssues = selectedRooms.some(r => rooms[r]?.etat === "Mauvais" || rooms[r]?.etat === "Moyen");

    return (
      <div>
        {/* Success banner */}
        <div style={{ ...card, background: "linear-gradient(135deg, #1d4ed8 0%, #3b82f6 100%)", color: "#fff", textAlign: "center", padding: "24px 16px" }}>
          <div style={{ fontSize: 40, marginBottom: 8 }}>✅</div>
          <div style={{ fontWeight: 800, fontSize: 18, marginBottom: 4 }}>État des lieux finalisé</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>
            {type === "entrant" ? "Entrée" : "Sortie"} — {date}
          </div>
        </div>

        {/* Logement */}
        <div style={card}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 10 }}>🏠 Logement</div>
          <div style={{ fontSize: 13, color: "#475569", lineHeight: 1.8 }}>
            <div><strong>Adresse :</strong> {logement.adresse || "—"}</div>
            <div><strong>Type :</strong> {logement.type || "—"} {logement.surface ? `— ${logement.surface} m²` : ""}</div>
            <div><strong>Propriétaire :</strong> {owner.nom || "—"}</div>
            <div><strong>Locataire :</strong> {tenant.nom || "—"}</div>
          </div>
        </div>

        {/* Pièces recap */}
        <div style={card}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 10 }}>
            🚪 Pièces inspectées ({roomsFilled}/{roomsTotal})
          </div>
          {hasIssues && (
            <div style={{ background: "#fef3c7", border: "1px solid #fbbf24", borderRadius: 8, padding: "8px 12px", fontSize: 12, color: "#92400e", marginBottom: 10 }}>
              ⚠️ Des anomalies ont été constatées
            </div>
          )}
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {selectedRooms.map(room => {
              const r = rooms[room] || {};
              return (
                <div key={room} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 10px", background: "#f8fafc", borderRadius: 8 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <span style={{ fontSize: 13, fontWeight: 600, color: "#1e293b" }}>{room}</span>
                    {r.photos?.length > 0 && <span style={{ fontSize: 11, color: "#64748b" }}>📷 {r.photos.length}</span>}
                  </div>
                  {r.etat ? (
                    <span style={{ fontSize: 11, padding: "2px 10px", borderRadius: 10, background: ETAT_COLORS[r.etat] + "22", color: ETAT_COLORS[r.etat], fontWeight: 700 }}>{r.etat}</span>
                  ) : (
                    <span style={{ fontSize: 11, color: "#cbd5e1" }}>Non renseigné</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Compteurs recap */}
        <div style={card}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 10 }}>📊 Compteurs</div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {[
              { key: "electricite", label: "Électricité", icon: "⚡", unit: "kWh" },
              { key: "eau", label: "Eau", icon: "💧", unit: "m³" },
              { key: "gaz", label: "Gaz", icon: "🔥", unit: "m³" }
            ].map(({ key, label, icon, unit }) => (
              <div key={key} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "8px 10px", background: "#f8fafc", borderRadius: 8 }}>
                <span style={{ fontSize: 13 }}>{icon} {label}</span>
                <span style={{ fontSize: 13, fontWeight: 700, color: compteurs[key] ? "#1e293b" : "#cbd5e1" }}>
                  {compteurs[key] ? `${compteurs[key]} ${unit}` : "—"}
                </span>
              </div>
            ))}
          </div>
          {cles.nombre && (
            <div style={{ marginTop: 10, padding: "8px 10px", background: "#f8fafc", borderRadius: 8, fontSize: 13, color: "#475569" }}>
              🔑 {cles.nombre} clé(s) — {cles.remises || cles.nombre} remise(s)
              {cles.detail && <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>{cles.detail}</div>}
            </div>
          )}
        </div>

        {/* Signatures recap */}
        <div style={card}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#1e293b", marginBottom: 12 }}>✍️ Signatures</div>
          <div style={{ display: "flex", gap: 12 }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, color: "#64748b", marginBottom: 6 }}>Propriétaire</div>
              {sigOwner && <img src={sigOwner} alt="sig owner" style={{ width: "100%", height: 60, objectFit: "contain", background: "#f8fafc", borderRadius: 8, border: "1px solid #e2e8f0" }} />}
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>{owner.nom || "—"}</div>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12, color: "#64748b", marginBottom: 6 }}>Locataire</div>
              {sigTenant && <img src={sigTenant} alt="sig tenant" style={{ width: "100%", height: 60, objectFit: "contain", background: "#f8fafc", borderRadius: 8, border: "1px solid #e2e8f0" }} />}
              <div style={{ fontSize: 11, color: "#94a3b8", marginTop: 4 }}>{tenant.nom || "—"}</div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div style={{ ...card, background: "#f0fdf4", border: "1px solid #bbf7d0" }}>
          <div style={{ fontWeight: 700, fontSize: 14, color: "#15803d", marginBottom: 8 }}>📄 Document généré</div>
          <div style={{ fontSize: 13, color: "#166534" }}>
            L'état des lieux a été enregistré avec succès. Vous pouvez imprimer ou partager ce document.
          </div>
        </div>

        <button style={{ ...btnPrimary, background: "#16a34a" }} onClick={() => window.print()}>
          🖨️ Imprimer / Télécharger PDF
        </button>
        <button style={btnSecondary} onClick={() => {
          setStep(0); setDone(false); setOwner({ nom: "", adresse: "", telephone: "" });
          setTenant({ nom: "", telephone: "", photo: null }); setLogement({ adresse: "", type: "", surface: "" });
          setRooms({}); setSelectedRooms(["Entrée", "Salon", "Cuisine", "Salle de bain", "WC"]);
          setCompteurs({ eau: "", gaz: "", electricite: "", photos: {} }); setCles({ nombre: "", remises: "" });
          setSigOwner(null); setSigTenant(null); setExpandedRoom(null);
        }}>
          ↺ Nouvel état des lieux
        </button>
      </div>
    );
  };

  const steps = [StepInfos, StepPieces, StepCompteurs, StepSignatures, StepRecap];
  const CurrentStep = steps[step];

  return (
    <div style={{ minHeight: "100vh", background: "#f1f5f9", fontFamily: "'Segoe UI', system-ui, sans-serif" }}>
      <div style={{ maxWidth: 560, margin: "0 auto", padding: "16px 12px 40px" }}>
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 20 }}>
          <div style={{ fontSize: 28, marginBottom: 4 }}>🏡</div>
          <h1 style={{ fontSize: 20, fontWeight: 800, color: "#1e293b", margin: 0 }}>État des Lieux</h1>
          <div style={{ fontSize: 12, color: "#94a3b8", marginTop: 2 }}>Application de constat</div>
        </div>

        <StepIndicator current={step} />
        <CurrentStep />
      </div>
    </div>
  );
}
